document.querySelector('form').addEventListener('submit', function (event) {
    event.preventDefault();
    alert('Thank you for your message!');
});


var swiper = new Swiper('.swipe-box', {
    slidesPerView: 3,
    spaceBetween: 10,
    navigation: {
      nextEl: '.next-btn',
      prevEl: '.prev-btn',
    },
    breakpoints: {
      600: {
        slidesPerView: 2,
      },
      400: {
        slidesPerView: 1,
      },
    },
  });